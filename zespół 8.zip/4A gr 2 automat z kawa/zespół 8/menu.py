MENU = {
    "espresso": {
        "skladniki": {
            "woda": 50,
            "kawa": 18,
            "mleko": 0,
        },
        "cena": 1.5,
    },
    "latte": {
        "skladniki": {
            "woda": 200,
            "mleko": 150,
            "kawa": 24,
        },
        "cena": 2.5,
    },
    "cappuccino": {
        "skladniki": {
            "woda": 250,
            "mleko": 100,
            "kawa": 24,
        },
        "cena": 3.0,
    }
}

zasoby = {
    "woda": 500,
    "mleko": 500,
    "kawa": 1000,
    "kasa": 0
}